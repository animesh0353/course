
public class Node {

	//int id;
	long nodeStart;
	long nodeEnd;
	double nodeStartLatitude;
	double nodeStartLongitude;
	double nodeEndLatitude;
	double nodeEndLongitude;
	double pickUpProb;
	double fare;
	double timeTaken;
	
	public Node(long nodeStart,	long nodeEnd, double nodeStartLatitude,	double nodeStartLongitude,	double nodeEndLatitude,	double nodeEndLongitude, double pickUpProb,	double fare, double timeTaken)
	{
		// TODO Auto-generated constructor stub
		this.nodeStart = nodeStart;
		this.nodeEnd = nodeEnd;
		this.nodeStartLatitude = nodeStartLatitude;
		this.nodeStartLongitude = nodeStartLongitude;
		this.nodeEndLatitude = nodeEndLatitude;
		this.nodeEndLongitude = nodeEndLongitude;
		this.pickUpProb = pickUpProb;
		this.fare = fare;
		this.timeTaken = timeTaken;
		
	}
	void nodePrint()
	{
		System.out.println(nodeStart+" "+nodeEnd+" "+nodeStartLatitude+" "+nodeStartLongitude+" "+nodeEndLatitude+" "+nodeEndLongitude+" "+pickUpProb+" "+fare+" "+timeTaken);
	}
	void nodePrint2()
	{
		System.out.println(nodeStart+" "+nodeEnd+" ["+nodeStartLongitude+","+nodeStartLatitude+"],["+nodeEndLongitude+","+nodeEndLatitude+"],"+pickUpProb+" "+fare+" "+timeTaken);
	}
	
}
