import java.util.ArrayList;


public class nodeTree {
	
	Node nodeCurr;
	int depth;
	int profit;
	ArrayList<nodeTree> nodeChild;
	

	public nodeTree(Node n) {
		// TODO Auto-generated constructor stub
		nodeCurr = n;
		nodeChild = new ArrayList<nodeTree>();
		depth = 1;
		
	}
	
}
